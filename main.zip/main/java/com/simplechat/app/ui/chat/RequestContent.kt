package com.simplechat.app.ui.chat

import com.simplechat.app.data.Attachment
import com.simplechat.app.net.ImageInput
import com.simplechat.app.net.MessageContent
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * 组装一条 **user** 消息的 `content`。
 *
 * 三种形态，按"能简单就简单"排：
 *
 * | 附件 | content |
 * |---|---|
 * | 无 | 纯字符串 |
 * | 只有文本文件 | 纯字符串（附件内容按定界块拼进去） |
 * | 有图片 | content block 数组 |
 *
 * ### 为什么图片必须走数组
 *
 * 官方 Vision 指南明确：图片只能出现在 **user** 消息里，且必须写成
 * `{"type":"image_url","image_url":{"url":"data:image/jpeg;base64,..."}}`。
 * 放进 system / assistant 会直接 400。
 *
 * ### 图片会随每一轮请求重发
 *
 * 接口是无状态的，历史里的图片每次都要重新带上（这也是把它存进数据库、
 * 而不是用完即弃的原因）。token 账要按"每轮都算"来看。
 *
 * 抽成纯函数是为了能单测：这里错一处，表现是"模型对图片视而不见"
 * 或者"请求直接 400"，从界面上完全看不出是哪一环。
 */
fun userContent(text: String, attachments: List<Attachment>): JsonElement {
    if (attachments.isEmpty()) return MessageContent.text(text)

    val textFiles = attachments.filter { it.kind == Attachment.Kind.TEXT && it.fileId == null }
    val files = attachments.filter { !it.fileId.isNullOrBlank() }
    // 只发有内容的图片：落盘附件的 data 要靠 `prepareRequestAttachments` 读回，
    // 万一漏了那一步，空 base64 发上去只会 400（见 AnthropicRequestBuilder 的同一条注释）
    val images = attachments.filter { it.isImage && it.data.isNotBlank() }

    val body = buildString {
        append(text)
        textFiles.forEach { file ->
            if (isNotEmpty()) appendLine()
            appendLine()
            append(file.toPromptBlock())
        }
    }.trim()

    if (files.isNotEmpty()) return JsonArray(buildList {
        if (body.isNotBlank()) add(buildJsonObject { put("type", "text"); put("text", body) })
        files.forEach { file -> add(buildJsonObject { put("type", "file"); put("file_id", file.fileId) }) }
        if (images.isNotEmpty()) addAll(MessageContent.withImages("", images.map { ImageInput(it.toDataUrl(), ImageDetail) }) as JsonArray)
    })
    if (images.isEmpty()) return MessageContent.text(body)

    return MessageContent.withImages(
        text = body,
        images = images.map { ImageInput(it.toDataUrl(), detail = ImageDetail) },
    )
}

/**
 * 图片精度。
 *
 * 官方给了四档，这里固定用 `high`（保留原图，服务端再统一缩到约 1300×1300 等效）。
 *
 * 不用 `low` 的原因很实际：`low` 会把图**缩到 512×512**，
 * 而本项目最常见的图片用法就是"截图里有一段文字，帮我看看" ——
 * 512×512 下小字直接糊成一团。
 * 代价可控：每张图上限 1024 token，且只有带图的会话才会付这个成本。
 */
const val ImageDetail = "high"

/**
 * 附件折算的 token 估算，喂给上下文占用圆环。
 *
 * - 文本附件：按正文一样的规则估
 * - 图片：按官方给的**上限 1024/张** 记。实际通常低于这个数，
 *   但占用圆环宁可高估 —— 它要提示的是"快满了"，低估会让人措手不及。
 */
fun attachmentTokenEstimate(attachments: List<Attachment>): Int {
    if (attachments.isEmpty()) return 0
    return attachments.sumOf { attachment ->
        if (attachment.isImage) ImageTokenUpperBound
        else com.simplechat.app.data.TokenEstimate.of(attachment.data)
    }
}

/**
 * 这条历史消息值不值得发出去（OpenAI 兼容通道）。
 *
 * 历史里确实可能出现"什么都没有"的消息：回复出错 / 被中断后正文与思考都为空、
 * 或者一条既没正文也没附件的空 user。DeepSeek 官方对 `content: ""` 比较宽松，
 * 但不少兼容网关会直接 400（`content must not be empty`）——
 * 一条空消息让整段历史发不出去，代价远大于少发一条。
 *
 * 纯函数，有单测（`RequestContentTest`）。
 */
internal fun isSendableOutgoing(message: UiMessage): Boolean =
    message.content.isNotBlank() ||
        message.attachments.any { attachment ->
            when {
                !attachment.fileId.isNullOrBlank() -> true
                attachment.kind == Attachment.Kind.TEXT -> attachment.data.isNotBlank()
                attachment.isImage -> attachment.data.isNotBlank()
                else -> false
            }
        }

/** 官方 Vision 指南给出的单图 token 上限。 */
const val ImageTokenUpperBound = 1024
