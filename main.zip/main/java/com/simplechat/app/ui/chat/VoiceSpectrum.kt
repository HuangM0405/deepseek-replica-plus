package com.simplechat.app.ui.chat

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.log10
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

/** 实时频谱的柱子数量。[VoiceComposer] 与 [VoiceSpectrumAnalyzer] 共用。 */
internal const val VoiceSpectrumBars = 48

private const val BandMinHz = 100f
private const val BandMaxHz = 4_000f
private const val FloorDb = -60f
private const val CeilingDb = -25f
/** 松手后柱子衰减的速度：每帧保留多少上一帧的高度。 */
private const val Decay = 0.55f
private const val Silence = 1e-6f

/**
 * 把 20 ms 的 PCM16 麦克风音频变成 [VoiceSpectrumBars] 根 0..1 的柱子。
 *
 * 做的是「像官方那样会随声音起伏」的频谱，不是精确的声学分析：
 * 512 点 FFT（320 个真实样本 + 补零）、Blackman 窗（旁瓣低，短帧也不糊成一片）、
 * 100–4000 Hz 对数分频，每段取峰值幅度换算成 dB，再按 -60..-25 dB 归一化并给高频一点倾斜，
 * 最后在相邻柱之间做一次平滑、时间轴上快起慢落。
 *
 * 每个实例保存上一帧的高度，所以一次录音用一个实例；换一次录音就新建一个。
 */
internal class VoiceSpectrumAnalyzer(
    sampleRate: Int = 16_000,
    private val fftSize: Int = 512,
    private val bars: Int = VoiceSpectrumBars,
) {
    init {
        require(sampleRate > 0) { "sampleRate must be positive" }
        require(fftSize >= 64 && (fftSize and (fftSize - 1)) == 0) { "fftSize must be a power of two" }
        require(bars >= 2) { "need at least two bars" }
    }

    /** 窗口按「本帧真实样本数」铺满，末尾自然归零；补零到 [fftSize] 不产生断点。 */
    private val window = FloatArray(fftSize)
    private var windowCount = -1
    private val cosTable = FloatArray(fftSize / 2) { index ->
        cos(-2.0 * PI * index / fftSize).toFloat()
    }
    private val sinTable = FloatArray(fftSize / 2) { index ->
        sin(-2.0 * PI * index / fftSize).toFloat()
    }
    private val real = FloatArray(fftSize)
    private val imag = FloatArray(fftSize)
    private val current = FloatArray(bars)
    private val previous = FloatArray(bars)
    private val bandStart = IntArray(bars)
    private val bandEnd = IntArray(bars)
    private val bandCenter = FloatArray(bars)

    init {
        val ratio = (BandMaxHz / BandMinHz).toDouble()
        // 每根柱子只覆盖自己那一段：相邻中心相差 stepRatio，边界再各退半步。
        val stepRatio = ratio.pow(1.0 / (bars - 1))
        val halfStep = stepRatio.pow(0.5)
        val highestBin = fftSize / 2 - 1
        fun binOf(hz: Double): Int = (hz * fftSize / sampleRate).roundToInt().coerceIn(1, highestBin)

        for (bar in 0 until bars) {
            val offset = bar.toDouble() / (bars - 1)
            val center = BandMinHz * ratio.pow(offset)
            bandCenter[bar] = center.toFloat()
            val start = binOf(center / halfStep)
            val end = binOf(center * halfStep)
            bandStart[bar] = start
            bandEnd[bar] = max(start, end)
        }
    }

    /** [count] 是 [samples] 中本次真正读到的样本数，不足 [fftSize] 时补零。 */
    fun analyze(samples: ShortArray, count: Int): FloatArray {
        require(count in 0..samples.size) { "count $count outside 0..${samples.size}" }
        real.fill(0f)
        imag.fill(0f)
        val usable = min(count, fftSize)
        ensureWindow(usable)
        for (index in 0 until usable) {
            real[index] = samples[index] / 32768f * window[index]
        }
        fft()

        for (bar in 0 until bars) {
            var peak = 0f
            for (bin in bandStart[bar]..bandEnd[bar]) {
                peak = max(peak, hypot(real[bin], imag[bin]))
            }
            // 窗的相干增益约 0.42，这里按 4 / 样本数近似还原成正弦的峰值幅度。
            val amplitude = if (usable == 0) Silence else max(4f * peak / usable, Silence)
            val db = 20f * log10(amplitude) + 4f * log2(bandCenter[bar] / 1_000f)
            current[bar] = ((db.coerceIn(FloorDb, CeilingDb) - FloorDb) / (CeilingDb - FloorDb))
        }

        for (bar in 0 until bars) {
            val left = current[if (bar == 0) 0 else bar - 1]
            val right = current[if (bar == bars - 1) bars - 1 else bar + 1]
            val smoothed = (left + 2f * current[bar] + right) / 4f
            // 快起慢落：新的峰立刻抬起来，安静下来后按 Decay 逐帧退回去。
            previous[bar] = max(smoothed, previous[bar] * Decay)
        }
        return previous.copyOf()
    }

    private fun ensureWindow(count: Int) {
        if (count == windowCount) return
        windowCount = count
        if (count <= 1) {
            window.fill(0f)
            return
        }
        val denominator = (count - 1).toDouble()
        for (index in 0 until count) {
            val phase = 2.0 * PI * index / denominator
            window[index] = (0.42 - 0.5 * cos(phase) + 0.08 * cos(2.0 * phase)).toFloat()
        }
        for (index in count until fftSize) window[index] = 0f
    }

    /** 原地 radix-2 迭代 FFT。旋转因子来自预计算表，避免每帧重算三角函数。 */
    private fun fft() {
        val n = fftSize
        var reversed = 0
        for (index in 1 until n) {
            var bit = n shr 1
            while (reversed and bit != 0) {
                reversed = reversed xor bit
                bit = bit shr 1
            }
            reversed = reversed xor bit
            if (index < reversed) {
                val tr = real[index]
                real[index] = real[reversed]
                real[reversed] = tr
                val ti = imag[index]
                imag[index] = imag[reversed]
                imag[reversed] = ti
            }
        }

        var length = 2
        while (length <= n) {
            val half = length / 2
            val step = n / length
            var offset = 0
            while (offset < n) {
                for (index in 0 until half) {
                    val twiddle = index * step
                    val wRe = cosTable[twiddle]
                    val wIm = sinTable[twiddle]
                    val even = offset + index
                    val odd = even + half
                    val oddRe = real[odd] * wRe - imag[odd] * wIm
                    val oddIm = real[odd] * wIm + imag[odd] * wRe
                    real[odd] = real[even] - oddRe
                    imag[odd] = imag[even] - oddIm
                    real[even] += oddRe
                    imag[even] += oddIm
                }
                offset += length
            }
            length = length shl 1
        }
    }
}
