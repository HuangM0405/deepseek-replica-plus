package com.simplechat.app.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.simplechat.app.R
import com.simplechat.app.ui.common.AppIcons
import com.simplechat.app.ui.common.CapsuleButton
import com.simplechat.app.ui.common.IconCircleButton
import com.simplechat.app.ui.common.SheetEnterMs
import com.simplechat.app.ui.common.SheetExitMs
import com.simplechat.app.ui.common.popupScrimLayer
import com.simplechat.app.ui.common.popupSheetLayer
import com.simplechat.app.ui.common.rememberPopupMotion
import com.simplechat.app.ui.theme.LocalChatColors

/**
 * 正文角标点开后的来源预览卡。
 *
 * 与 [SourceSheet] 的分工：来源列表（多个）仍然走底部来源面板；单个角标只弹这一张
 * 紧凑卡片 —— 站点、标题、摘要和三行以内的原文提示，先看清说的是哪个网页，再决定
 * 要不要跳浏览器。点卡片外面或右上角关闭。
 *
 * 同样刻意不做内置 WebView（见 [SourceSheet] 的说明），"打开网页"交给系统浏览器。
 */
@Composable
internal fun CitationCard(
    source: SourceRef,
    onDismiss: () -> Unit,
) {
    val colors = LocalChatColors.current
    val uri = LocalUriHandler.current
    /*
     * 进出场交给 rememberPopupMotion：先只把 visible 关掉，滑动播完才 onDismiss。
     * 直接调 onDismiss 的话父级会当场把节点摘掉，退出动画根本没机会播。
     */
    var visible by remember { mutableStateOf(true) }
    val motion = rememberPopupMotion(
        visible = visible,
        onDismissed = onDismiss,
        enterMs = SheetEnterMs,
        exitMs = SheetExitMs,
    )
    // 下滑行程 = 卡片自身高度，卡片内容变高变矮都不用改参数
    var cardHeight by remember { mutableStateOf(0f) }

    Dialog(
        onDismissRequest = { visible = false },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            /*
             * 遮罩与卡片分开做：同一个进度分别驱动，但两者不互相淡 ——
             * 卡片若跟着遮罩一起淡，滑到一半会显得发虚。
             */
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .popupScrimLayer(motion.progress)
                    .background(colors.scrim)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = { visible = false },
                    ),
            )
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .onSizeChanged { cardHeight = it.height.toFloat() }
                    .popupSheetLayer(motion.progress) { cardHeight }
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 12.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(colors.card)
                    // 吞掉卡片内的点击，避免落到外面的关闭层上
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {},
                    )
                    .padding(18.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    SiteIcon(source = source, size = 20.dp)
                    Text(
                        text = source.siteName.ifBlank { citationHost(source.url) },
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.processText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        text = source.index.toString(),
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.processText,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(colors.markdownInlineCode)
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                    )
                    IconCircleButton(
                        icon = AppIcons.Close,
                        contentDescription = stringResource(R.string.action_close),
                        onClick = { visible = false },
                        size = 30.dp,
                        iconSize = 16.dp,
                        background = colors.fieldBackground,
                        tint = colors.processText,
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    text = source.title.ifBlank { source.url },
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
                source.snippet?.takeIf { it.isNotBlank() }?.let { snippet ->
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = snippet,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.placeholder,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                source.pageAge?.takeIf { it.isNotBlank() }?.let { age ->
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = age.take(10),
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.placeholder,
                        maxLines = 1,
                    )
                }
                Spacer(Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                ) {
                    CapsuleButton(
                        text = stringResource(R.string.citation_open_page),
                        onClick = {
                            // 先跳浏览器，卡片再滑下去 —— 两件事互不等待
                            if (source.url.isNotBlank()) runCatching { uri.openUri(source.url) }
                            visible = false
                        },
                    )
                }
            }
        }
    }
}

private fun citationHost(url: String): String =
    url.substringAfter("://").substringBefore('/').substringBefore('?').ifBlank { url }
