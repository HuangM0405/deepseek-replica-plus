package com.simplechat.app.ui.common

import android.animation.ValueAnimator
import android.view.View
import android.view.Window
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.window.DialogWindowProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner

/**
 * 系统是否要求「减弱动态」（开发者选项里的动画缩放被关掉、或省电模式）。
 *
 * 默认 false：拿不到就照常播 —— 宁可多播一次，也不要因为读不到而让界面变成硬切。
 */
val LocalReduceMotion = compositionLocalOf { false }

/**
 * 读取系统的动画开关。
 *
 * 只在 Lifecycle.Event.ON_RESUME 时重读：开发者选项是在设置里切的，
 * 来回切一次就会经过一次 resume，够用了，不必为它挂全局监听。
 */
@Composable
fun rememberReduceMotion(): Boolean {
    var reduce by remember { mutableStateOf(!ValueAnimator.areAnimatorsEnabled()) }
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                reduce = !ValueAnimator.areAnimatorsEnabled()
            }
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }
    return reduce
}

/**
 * 一个弹层的进出场进度：0 = 完全隐藏，1 = 完全就位。
 *
 * 关键点：**是否消失由这里管，不由父级立刻撤掉节点**。
 * 父级的 onDismiss 只在退场播完之后才被调一次 —— 否则 Dialog 会当场被移除，
 * 退出动画根本没机会播，用户看到的还是一次硬闪。
 */
@Stable
class PopupMotion internal constructor(
    private val animatable: Animatable<Float, AnimationVector1D>,
    val reduceMotion: Boolean,
) {
    /**
     * 进度。**只在绘制阶段读**（graphicsLayer / Canvas 的 lambda 里），
     * 读在组合阶段会变成每帧重组。
     */
    val progress: State<Float> = object : State<Float> {
        override val value: Float get() = animatable.value
    }
}

/**
 * @param visible 父级是否还希望它显示。置 false 会触发退场，退场结束后调用 [onDismissed]。
 * @param onDismissed 退场播完的回调 —— 在这里把父级的状态清掉、摘掉节点。
 */
@Composable
fun rememberPopupMotion(
    visible: Boolean,
    onDismissed: () -> Unit,
    enterMs: Int = DialogEnterMs,
    exitMs: Int = DialogExitMs,
): PopupMotion {
    val reduceMotion = LocalReduceMotion.current
    val animatable = remember { Animatable(0f) }
    val motion = remember(reduceMotion) { PopupMotion(animatable, reduceMotion) }
    val dismiss by rememberUpdatedState(onDismissed)

    LaunchedEffect(visible, reduceMotion) {
        if (visible) {
            if (reduceMotion) {
                animatable.snapTo(1f)
            } else {
                animatable.animateTo(1f, tween(enterMs, easing = PopupEasing))
            }
        } else {
            if (reduceMotion) {
                animatable.snapTo(0f)
            } else if (animatable.value > 0f) {
                animatable.animateTo(0f, tween(exitMs, easing = PopupEasing))
            }
            dismiss()
        }
    }

    return motion
}

/** 居中弹窗的位移/缩放/淡入层。 */
fun Modifier.popupModalLayer(progress: State<Float>): Modifier = graphicsLayer {
    val p = progress.value
    val scale = modalScale(p)
    scaleX = scale
    scaleY = scale
    alpha = p
}

/** 遮罩的淡入淡出层（只动 alpha，不动颜色，不会一帧一帧地重组）。 */
fun Modifier.popupScrimLayer(progress: State<Float>, maxAlpha: Float = 1f): Modifier = graphicsLayer {
    alpha = scrimAlpha(progress.value, maxAlpha)
}

/**
 * 底部卡片的下滑层。
 *
 * @param heightPx 卡片实测高度（onSizeChanged 记下来）。用自身高度当行程，
 *   卡片改版变高变矮都不用再调参数。
 */
fun Modifier.popupSheetLayer(progress: State<Float>, heightPx: () -> Float): Modifier = graphicsLayer {
    translationY = sheetOffsetPx(progress.value, heightPx())
}

/** 系统弹窗遮罩的平台默认不透明度（android:backgroundDimAmount）。 */
private const val PlatformDialogDim = 0.6f

/**
 * 让系统 Dialog 的窗口遮罩跟着同一份进度淡入淡出。
 *
 * 不做这件事的话，卡片是柔的、背后那片黑却是「啪」一下就有了 —— 那一下比卡片本身更显眼。
 * 用 snapshotFlow 读进度，所以不会每帧重组；退场结束后 dim 也回到 0，不会留下半透明残影。
 */
@Composable
fun DialogDim(progress: State<Float>, maxAmount: Float = PlatformDialogDim) {
    val view = LocalView.current
    /*
     * 平台遮罩是窗口一出现就有的（0.6），不是动画。第一帧就把它压到 0，
     * 之后完全由进度驱动 —— 晚一帧才关，屏幕上会先「啪」地黑一下再亮回来。
     * SideEffect 在本次组合的绘制之前跑，正好赶在首帧前面。
     */
    SideEffect {
        val window = view.findDialogWindow() ?: return@SideEffect
        if (window.attributes.dimAmount != 0f) window.setDimAmount(0f)
    }
    LaunchedEffect(view) {
        val window = view.awaitDialogWindow() ?: return@LaunchedEffect
        window.setDimAmount(0f)
        snapshotFlow { progress.value }.collect { p ->
            window.setDimAmount(maxAmount * p.coerceIn(0f, 1f))
        }
    }
}

/**
 * 往视图树上方找承载这个 Dialog 的窗口。
 *
 * 不能只看 view.parent：Compose 的 Dialog 内容外面还套着 [androidx.compose.ui.platform.AbstractComposeView]，
 * 隔几层才到 DialogWindowProvider。找不到就当作没有，安全降级。
 */
private fun View.findDialogWindow(): Window? {
    var node: View? = this
    while (node != null) {
        if (node is DialogWindowProvider) return node.window
        node = node.parent as? View
    }
    return null
}

/** Dialog 的窗口可能比内容晚一步才挂上，等几帧再找，别因为第一次没找到就永远不管遮罩了。 */
private suspend fun View.awaitDialogWindow(): Window? {
    repeat(8) {
        findDialogWindow()?.let { return it }
        withFrameNanos { }
    }
    return findDialogWindow()
}
