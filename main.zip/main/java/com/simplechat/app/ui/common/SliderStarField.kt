package com.simplechat.app.ui.common

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/**
 * 滑块轨道里的星光点。
 *
 * 形制参考 Codex 的思考强度条：胶囊轨道从深蓝渐变到紫，填充区里散着一层细碎白点，
 * 各自以不同周期明灭，像被光带照亮的星尘。位置都是**归一化**的：横向 0..1 铺满整条
 * 轨道、纵向 0..1 铺满胶囊高度，所以换宽度只换数量、不换图案。
 *
 * 纯数据 + 绘制，不持有 Compose 状态，可以直接单测。
 */
internal class SliderStarField(
    val count: Int,
    seed: Int = DefaultStarSeed,
) {
    class Star(
        /** 轨道归一化横坐标。 */
        val x: Float,
        /** 胶囊内归一化纵坐标。 */
        val y: Float,
        /** 半径，dp。 */
        val radiusDp: Float,
        /** 最亮时的透明度。 */
        val brightness: Float,
        /** 起相 0..1，用来错开各自的明灭节奏。 */
        val phase: Float,
        /** 一个明灭来回的时长，毫秒。 */
        val periodMs: Float,
    )

    val stars: List<Star> = buildList(count) {
        val random = Random(seed)
        repeat(count) {
            add(
                Star(
                    x = random.nextFloat(),
                    y = random.nextFloat(),
                    radiusDp = MinStarRadiusDp + random.nextFloat() * (MaxStarRadiusDp - MinStarRadiusDp),
                    brightness = MinStarBrightness +
                        random.nextFloat() * (MaxStarBrightness - MinStarBrightness),
                    phase = random.nextFloat(),
                    periodMs = MinStarPeriodMs + random.nextFloat() * (MaxStarPeriodMs - MinStarPeriodMs),
                ),
            )
        }
    }

    /**
     * 画一层星光。
     *
     * [fillRightPx] 是已走到的横坐标：只点亮填充区里的点，且落在胶囊圆角外的点直接跳过 ——
     * 省掉每帧构造裁剪路径，纯算术就够。
     * [alphaScale] 由思考档位给：档位越高越亮。
     */
    fun draw(
        scope: DrawScope,
        widthPx: Float,
        fillRightPx: Float,
        centerY: Float,
        trackHeightPx: Float,
        timeMs: Float,
        alphaScale: Float = 1f,
    ) {
        if (fillRightPx <= 0f || widthPx <= 0f) return
        val capRadius = trackHeightPx / 2f
        val top = centerY - capRadius
        val scale = alphaScale.coerceIn(0f, 1f)
        stars.forEach { star ->
            val x = star.x * widthPx
            if (x > fillRightPx) return@forEach
            val y = top + star.y * trackHeightPx
            val wave = starTwinkle(star, timeMs)
            val dot = with(scope) { star.radiusDp.dp.toPx() } * (0.8f + 0.2f * wave)
            if (!insideCapsule(x, y, 0f, fillRightPx, centerY, capRadius, dot)) return@forEach
            scope.drawCircle(
                color = Color.White.copy(alpha = starAlpha(star, wave) * scale),
                radius = dot,
                center = Offset(x, y),
            )
        }
    }
}

/**
 * 一条约 320dp 的轨道上大约铺这么多点；太密就成了噪点。
 *
 * [level] 是档位烈度 0..1：低档只亮三分之一，满档铺满。每颗点的位置由固定种子
 * 顺序生成，所以改档位取到的是同一串点的**前缀** —— 只会增减尾部几颗，不会满盘重排。
 */
internal fun starCountFor(widthDp: Float, level: Float = 1f): Int {
    val base = (widthDp * 0.10f).roundToInt().coerceIn(MinStarCount, MaxStarCount)
    val lit = StarBaseDensity + (1f - StarBaseDensity) * level.coerceIn(0f, 1f)
    return (base * lit).roundToInt().coerceIn(0, base)
}

/**
 * 星光闪烁的速度倍率：档位越高转得越快。
 *
 * 只改**时间推进的速率**，不改每颗点的周期 —— 中途换档时相位仍然连续，不会集体跳相。
 */
internal fun starTwinkleSpeed(level: Float): Float =
    MinTwinkleSpeed + (MaxTwinkleSpeed - MinTwinkleSpeed) * level.coerceIn(0f, 1f)

/** 明灭曲线：0..1 的正弦，相位由 [SliderStarField.Star.phase] 错开。 */
internal fun starTwinkle(star: SliderStarField.Star, timeMs: Float): Float {
    val turns = timeMs / star.periodMs + star.phase
    return 0.5f + 0.5f * sin((2.0 * PI * turns).toFloat())
}

/** 当前透明度：最暗留 [MinStarAlpha]，免得闪灭到彻底消失。 */
internal fun starAlpha(star: SliderStarField.Star, wave: Float): Float =
    star.brightness * (MinStarAlpha + (1f - MinStarAlpha) * wave.coerceIn(0f, 1f))

/** 点是否落在胶囊内（[margin] 是要留出的半径，避免圆点压到边上）。 */
internal fun insideCapsule(
    x: Float,
    y: Float,
    left: Float,
    right: Float,
    centerY: Float,
    radius: Float,
    margin: Float = 0f,
): Boolean {
    if (right - left <= 0f || radius <= margin) return false
    val innerLeft = left + radius
    val innerRight = right - radius
    if (x in innerLeft..innerRight) return abs(y - centerY) <= radius - margin
    val capX = if (x < innerLeft) innerLeft else innerRight
    return hypot(x - capX, y - centerY) <= radius - margin
}

private const val DefaultStarSeed = 0x5EED
private const val MinStarCount = 16
private const val MaxStarCount = 40
private const val MinStarRadiusDp = 0.6f
private const val MaxStarRadiusDp = 1.7f
private const val MinStarBrightness = 0.55f
private const val MaxStarBrightness = 1f
private const val MinStarPeriodMs = 2_400f
private const val MaxStarPeriodMs = 5_200f
private const val MinStarAlpha = 0.35f
private const val StarBaseDensity = 0.35f
private const val MinTwinkleSpeed = 0.55f
private const val MaxTwinkleSpeed = 1.9f
