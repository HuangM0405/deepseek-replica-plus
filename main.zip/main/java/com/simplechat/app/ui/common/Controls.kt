package com.simplechat.app.ui.common

import com.simplechat.app.R
import androidx.compose.ui.res.stringResource
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import kotlinx.coroutines.delay
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties
import kotlin.math.roundToInt
import androidx.compose.ui.unit.dp
import com.simplechat.app.ui.theme.LocalChatColors
import androidx.compose.ui.graphics.Shape
import androidx.compose.runtime.withFrameNanos
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import kotlin.math.abs

// ══════════════════════════════════════════════════════════
//  布局刻度
// ══════════════════════════════════════════════════════════

/**
 * 全局间距刻度。
 *
 * 只有一个目的：**别让 12 / 14 / 16 混着用**。此前抽屉里搜索框内缩 16dp、
 * 会话行内缩 8dp，两个色块左右对不齐，一眼就能看出来。
 */
object Space {
    /** 屏幕左右安全内边距。所有页面的一级内容都从这里开始。 */
    val Screen = 16.dp

    /** 卡片 / 浮层 / 面板的内部内边距。 */
    val Card = 16.dp

    /** 行内元素之间（图标与文字、相邻按钮）。 */
    val Inline = 12.dp

    /** 组内元素的纵向间距。 */
    val Gap = 8.dp

    /** 分组之间的纵向间距。 */
    val Section = 24.dp

    /**
     * 单行条目的统一行高：抽屉会话行、设置里的每一行、菜单项**同一个数**。
     *
     * 抽屉原来 46dp、菜单 46dp、设置行 50/54dp 各写各的，同一块屏幕上三种节奏。
     * 对齐 DeepSeek 官方栅格：参考截图行距约 100px（≈2.19px/dp）→ 46dp，
     * 即「图标 + 22dp 文字 + 上下各 12dp」。抽屉、设置、菜单仍共用这一个数。
     */
    val Row = 46.dp

    /** 单行条目的上下内边距。与 [Row] 配对使用。 */
    val RowPadY = 12.dp

    /** 抽屉、设置和菜单的行首图标尺寸。 */
    val Icon = 18.dp

    /** 行首图标与文字的间距。 */
    val IconGap = 12.dp
}

// ══════════════════════════════════════════════════════════
//  圆角规格：只有四档
// ══════════════════════════════════════════════════════════

/** 胶囊形（全圆角）。**所有**输入框、搜索框、带文字 / 带箭头的按钮一律用它。 */
val PillShape = RoundedCornerShape(percent = 50)

/**
 * 胶囊形搜索 / 输入条的**粗细**（内边距的纵向值）。
 *
 * 抽屉的搜索框与全屏搜索页的搜索框共用 —— 之前一处 10dp、一处 12dp，
 * 两条并排看明显一个粗一个细。**以搜索页那条为准**，横向内边距各留各的
 * （抽屉要与分组标题对齐，见 `HistoryDrawer.DrawerTextInset`）。
 */
val FieldThickness = 12.dp

/** 列表行、小卡片。 */
val SoftShape = RoundedCornerShape(14.dp)

/** 大卡片与浮层菜单。 */
val MenuShape = RoundedCornerShape(18.dp)

/** 多行容器（输入栏、输入面板）。 */
val ContainerShape = RoundedCornerShape(24.dp)

/**
 * 消息气泡：靠近发出侧的一角收紧，给内容一个方向感。
 *
 * 22dp / 4dp 对齐官方客户端（Replica UserMessage.module.css:56 的
 * 22px 22px 4px 22px）——18dp 偏收，看起来像普通圆角卡片而不是气泡。
 */
val BubbleShapeOut = RoundedCornerShape(22.dp, 22.dp, 4.dp, 22.dp)
val BubbleShapeIn = RoundedCornerShape(22.dp, 22.dp, 22.dp, 4.dp)

// ══════════════════════════════════════════════════════════
//  滑块
// ══════════════════════════════════════════════════════════

/**
 * 胶囊轨道 + 深蓝到紫的渐变 + 星光 + 白色圆钮。
 *
 * 形制参考 Codex 的思考强度条。以前那版是细线 + 刻度齿 + 火花，信息多但吵；
 * 现在「有几档」交给离散吸附和调用方标题里的档位名，轨道只负责进度。
 *
 * 手感上的三条旧约定都保留：
 * - 指示器是**正圆**，按下时**放大**（触感反馈）；
 * - **点击轨道可直接跳转**，而不是只能拖动 —— Material 的 Slider 在
 *   离散档位下点轨道只走一格，甚至没反应；
 * - 拖动只改**绘制**、不回调：离散档位只在**跨档的瞬间**回调一次，松手后
 *   滑块用弹簧滑到档位中心。原来每帧都 onValueChange → 调用方每帧 copy
 *   一份 settings → 整块面板每帧重组，手感就是"卡"。
 *
 * @param intervals 档位间隔数；0 表示连续无刻度。实际取值由调用方自行吸附。
 * @param sparkIntensity 0..1 的视觉烈度：档位越高，星光越多、越亮、闪得越快；0 不点亮。
 */
private val SliderTrackHeight = 30.dp
private val SliderKnobSize = 40.dp
private val SliderHeight = 48.dp
private const val SliderKnobPressedScale = 1.12f

/** 星光时间轴单帧最多推进多少纳秒（48ms）：卡顿或切回前台时不让星星瞬移。 */
private const val MaxTwinkleStepNs = 48_000_000L
private val SliderGradient = listOf(
    Color(0xFF3D5BFF),
    Color(0xFF6C5CE7),
    Color(0xFFA886FF),
)

/**
 * 把 0..1 的位置吸附到 [intervals] 等分刻度上（四舍五入，过中点即算下一格）。
 *
 * 静止位置、回调值、松手后的落点都走这一个函数，三处口径才不会各算各的。
 */
internal fun snapToIntervals(fraction: Float, intervals: Int): Float {
    val clamped = fraction.coerceIn(0f, 1f)
    if (intervals <= 0) return clamped
    return (clamped * intervals).roundToInt() / intervals.toFloat()
}

@Composable
fun AppSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    valueRange: ClosedFloatingPointRange<Float> = 0f..1f,
    intervals: Int = 0,
    enabled: Boolean = true,
    /** 手势结束时回调一次。用于"拖动时只预览、松手才落盘"。 */
    onValueChangeFinished: (() -> Unit)? = null,
    /** 0..1 的视觉烈度：大于 0 才点亮星光；越大，点越多、越亮、闪得越快。 */
    sparkIntensity: Float = 0f,
) {
    val colors = LocalChatColors.current
    val density = LocalDensity.current

    var pressed by remember { mutableStateOf(false) }
    var dragging by remember { mutableStateOf(false) }
    var width by remember { mutableStateOf(0f) }
    // 拖动位置只在 Canvas 的绘制闭包里读：写成普通 State 并在组合阶段读，会每帧重组。
    val dragFraction = remember { mutableFloatStateOf(0f) }
    // 上一次真正回调出去的档位，用于去重。NaN = 还没有值，第一次必定放行。
    val lastEmitted = remember { mutableFloatStateOf(Float.NaN) }
    // pointerInput 的 block 只在 key 变化时重建，直接闭包捕获会拿到旧 lambda
    val finishedCallback by rememberUpdatedState(onValueChangeFinished)

    val trackHeight = with(density) { SliderTrackHeight.toPx() }
    val pillRadius = trackHeight / 2f
    // 圆钮中心能到达的两端：各留一个半径，圆钮才不会探出胶囊。
    val edge = with(density) { SliderKnobSize.toPx() / 2f }

    val span = (valueRange.endInclusive - valueRange.start).takeIf { it > 0f } ?: 1f
    val valueFraction = ((value - valueRange.start) / span).coerceIn(0f, 1f)
    // 外部改档（点标签、读设置）时，滑块要落在刻度中心而不是刻度之间的任意点。
    val restingFraction = snapToIntervals(valueFraction, intervals)
    /*
     * 手指离开后**当帧**要显示的位置。
     *
     * 必须是普通状态、且松手那一次同步写进去。这里原来是 Animatable：松手后
     * 得等 LaunchedEffect 里的 snapTo 追上手指，中间那一两帧画的是上一档 ——
     * 表现就是「啪」地闪一下（没过中点朝回闪，过了中点朝前闪）。
     */
    val settledFraction = remember { mutableFloatStateOf(restingFraction) }
    val level = sparkIntensity.coerceIn(0f, 1f)

    val emitValue by rememberUpdatedState<(Float) -> Unit> { raw ->
        onValueChange(valueRange.start + raw * span)
    }

    /*
     * 星光的时间源：只在轨道被点亮时每帧推进。读它的只有 Canvas，所以只重绘不重组。
     *
     * 累计的是**按档位加速过**的时间：档位越高闪得越快。用累计值而不是 `纳秒 × 倍率`,
     * 换档时相位不会整体跳一下。
     */
    val twinkleNs = remember { mutableLongStateOf(0L) }
    val starsActive = enabled && level > 0.01f
    val twinkleSpeed by rememberUpdatedState(starTwinkleSpeed(level))

    LaunchedEffect(starsActive) {
        if (!starsActive) {
            twinkleNs.longValue = 0L
            return@LaunchedEffect
        }
        var last = withFrameNanos { it }
        while (true) {
            withFrameNanos { now ->
                // 单帧最多推 48ms：从后台切回来时别让星星瞬移一大段
                val delta = (now - last).coerceIn(0L, MaxTwinkleStepNs)
                last = now
                twinkleNs.longValue += (delta * twinkleSpeed.toDouble()).toLong()
            }
        }
    }

    // 宽度或档位变了才重新铺点：同一串种子的前缀，只会增减尾部的点。
    val starCount = starCountFor(with(density) { width.toDp().value }, level)
    val starField = remember(starCount) { SliderStarField(starCount) }
    val knobScale by animateFloatAsState(
        targetValue = if (pressed) SliderKnobPressedScale else 1f,
        animationSpec = tween(if (pressed) PressDownMs else PressReleaseMs, easing = PressEasing),
        label = "sliderKnob",
    )

    /*
     * 松手（或别处改档）后弹到档位中心。拖动中不动，否则会和手指抢位置。
     *
     * 用非挂起的 animate 直接写状态，起点就是手指最后的位置：松手那一帧画出来的
     * 已经是手指所在处，不会先跳回旧档位再弹走。
     */
    LaunchedEffect(dragging, restingFraction) {
        if (dragging) return@LaunchedEffect
        val from = settledFraction.floatValue.coerceIn(0f, 1f)
        if (abs(from - restingFraction) < 0.0005f) {
            settledFraction.floatValue = restingFraction
            return@LaunchedEffect
        }
        animate(
            initialValue = from,
            targetValue = restingFraction,
            animationSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow),
        ) { value, _ ->
            settledFraction.floatValue = value
        }
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(SliderHeight)
                .onSizeChanged { width = it.width.toFloat() }
                .pointerInput(enabled, valueRange, intervals, width) {
                    if (!enabled) return@pointerInput
                    val usable = (width - edge * 2f).coerceAtLeast(1f)

                    fun fractionAt(x: Float): Float = ((x - edge) / usable).coerceIn(0f, 1f)

                    fun emit(fraction: Float) {
                        emitValue(fraction.coerceIn(0f, 1f))
                    }

                    // 离散档位：只在跨档时回调，避免每帧都让外面重组一次。
                    fun emitSnapped(fraction: Float) {
                        val snapped = snapToIntervals(fraction, intervals)
                        if (snapped == lastEmitted.floatValue) return
                        lastEmitted.floatValue = snapped
                        emit(snapped)
                    }

                    awaitEachGesture {
                        val down = awaitFirstDown()
                        pressed = true
                        dragging = true
                        lastEmitted.floatValue = Float.NaN
                        // 按下就跟手：手指落在哪，圆钮就在哪。
                        // 以前离散档位按下会先跳到「最近档」，那一下本身就是一次突跳；
                        // 现在只把回调值吸附到档位，圆钮始终跟着手指。
                        val startFraction = fractionAt(down.position.x)
                        dragFraction.floatValue = startFraction
                        if (intervals > 0) emitSnapped(startFraction) else emit(startFraction)
                        try {
                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                                if (!change.pressed) break
                                val fraction = fractionAt(change.position.x)
                                dragFraction.floatValue = fraction
                                if (intervals > 0) emitSnapped(fraction) else emit(fraction)
                                change.consume()
                            }
                        } finally {
                            /*
                             * 松手或手势被别处抢走，都把显示位置就地交给手指最后的位置，
                             * 再让弹簧从那里去档位中心 —— 中间不留一帧旧值。
                             */
                            settledFraction.floatValue = dragFraction.floatValue.coerceIn(0f, 1f)
                            pressed = false
                            dragging = false
                        }
                        finishedCallback?.invoke()
                    }
                },
            contentAlignment = Alignment.Center,
        ) {
            Canvas(modifier = Modifier.fillMaxWidth().height(SliderHeight)) {
                val cy = size.height / 2f
                val pillTop = cy - pillRadius
                // 拖动时跟手；静止时读松手落点，弹簧已经把它带到档位中心。
                val shown = (if (dragging) dragFraction.floatValue else settledFraction.floatValue)
                    .coerceIn(0f, 1f)
                val thumbX = edge + (size.width - edge * 2f) * shown
                // 填充左端恒为 0；右端压在圆钮中心，圆钮自己会盖住那一小段。
                val fillRight = thumbX.coerceAtLeast(pillRadius)

                drawRoundRect(
                    color = colors.fieldBackground,
                    topLeft = Offset(0f, pillTop),
                    size = Size(size.width, trackHeight),
                    cornerRadius = CornerRadius(pillRadius, pillRadius),
                )
                if (fillRight > 0f) {
                    drawRoundRect(
                        brush = if (enabled) {
                            Brush.horizontalGradient(SliderGradient, startX = 0f, endX = size.width)
                        } else {
                            SolidColor(colors.outline)
                        },
                        topLeft = Offset(0f, pillTop),
                        size = Size(fillRight, trackHeight),
                        cornerRadius = CornerRadius(pillRadius, pillRadius),
                    )
                }
                if (enabled && level > 0.01f) {
                    // 星光：只读 twinkleNs，绘制阶段更新，不触发重组。
                    starField.draw(
                        scope = this,
                        widthPx = size.width,
                        fillRightPx = fillRight,
                        centerY = cy,
                        trackHeightPx = trackHeight,
                        timeMs = twinkleNs.longValue / 1_000_000f,
                        alphaScale = 0.55f + 0.45f * level,
                    )
                }

                // 圆钮：外面两圈柔光是投影。深色底用白光，浅色底用黑影。
                val knobRadius = edge * knobScale
                val center = Offset(thumbX, cy)
                val shade = if (colors.card.luminance() > 0.5f) Color.Black else Color.White
                drawCircle(shade.copy(alpha = 0.10f), knobRadius * 1.34f, center)
                drawCircle(
                    color = shade.copy(alpha = 0.14f),
                    radius = knobRadius * 1.10f,
                    center = Offset(center.x, center.y + 1.dp.toPx()),
                )
                drawCircle(Color.White, knobRadius, center)
                drawCircle(
                    color = shade.copy(alpha = 0.10f),
                    radius = knobRadius,
                    center = center,
                    style = Stroke(1.dp.toPx()),
                )
            }
        }

    }
}


// ══════════════════════════════════════════════════════════
//  进度环
// ══════════════════════════════════════════════════════════

/**
 * 环形进度。用于「上下文占用」这类**常驻**的少量信息。
 *
 * 比线性进度条省横向空间：一个环 + 4 个字符就能说清"1M 里用了 12k"，
 * 而输入栏第二行本来就很挤。
 */
@Composable
fun ProgressRing(
    progress: Float,
    color: Color,
    modifier: Modifier = Modifier,
    trackColor: Color = Color.Unspecified,
    size: Dp = 18.dp,
    strokeWidth: Dp = 2.dp,
) {
    val colors = LocalChatColors.current
    val resolvedTrack = if (trackColor == Color.Unspecified) colors.outline else trackColor
    val sweep = (progress.coerceIn(0f, 1f)) * 360f

    Canvas(modifier = modifier.size(size)) {
        val stroke = strokeWidth.toPx()
        val inset = stroke / 2f
        // 显式走 DrawScope.size —— 外层还有个同名参数 size: Dp，直接写会歧义
        val arcSize = Size(this.size.width - stroke, this.size.height - stroke)

        drawArc(
            color = resolvedTrack,
            startAngle = 0f,
            sweepAngle = 360f,
            useCenter = false,
            topLeft = Offset(inset, inset),
            size = arcSize,
            style = Stroke(width = stroke, cap = StrokeCap.Round),
        )
        if (sweep > 0f) {
            drawArc(
                color = color,
                // 从 12 点方向顺时针
                startAngle = -90f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(inset, inset),
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round),
            )
        }
    }
}

// ══════════════════════════════════════════════════════════
//  开关
// ══════════════════════════════════════════════════════════

/**
 * 紧凑胶囊开关 —— **全应用唯一的开关**。
 *
 * 不用 Material3 `Switch`：它默认 52×32dp，在设置列表和输入面板里比行标题还抢眼，
 * 而且深色下描边偏粗、滑块带一圈投影。这里 38×22dp，轨道胶囊形、滑块正圆 ——
 * 与「图标按钮是圆、带字按钮是胶囊」的规则保持一致。
 *
 * ⚠️ 想改开关大小**只改这里**。此前设置页和输入面板各写了一个 M3 `Switch`，
 * 于是同一个列表里出现了两种大小（52dp 与 40dp），一眼就看出不齐。
 *
 * 用 `toggleable` 而不是 `clickable`：读屏才会念"开关，已选中"，而不是"按钮"。
 */
@Composable
fun AppSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    val colors = LocalChatColors.current
    val trackWidth = 38.dp
    val trackHeight = 22.dp
    val thumbSize = 16.dp
    val padding = 3.dp

    val thumbOffset by animateDpAsState(
        targetValue = if (checked) trackWidth - thumbSize - padding else padding,
        animationSpec = tween(SwitchThumbMs, easing = MotionEasing),
        label = "switchThumb",
    )

    val trackColor = when {
        !enabled -> colors.divider
        checked -> MaterialTheme.colorScheme.primary
        // 关闭态的轨道用描边色而不是另一种灰：深色下才和卡片分得开
        else -> colors.outline
    }

    Box(
        modifier = modifier
            .size(trackWidth, trackHeight)
            .clip(PillShape)
            .background(trackColor)
            .toggleable(
                value = checked,
                enabled = enabled,
                role = Role.Switch,
                onValueChange = onCheckedChange,
            ),
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(
            modifier = Modifier
                .padding(start = thumbOffset)
                .size(thumbSize)
                .clip(CircleShape)
                .background(if (enabled) Color.White else colors.placeholder),
        )
    }
}

/** 滑块滑动时长。够看出"滑过去"，又不至于点完还等它。 */
private const val SwitchThumbMs = 160

// ══════════════════════════════════════════════════════════
//  按钮：只有两种形状
// ══════════════════════════════════════════════════════════

/**
 * **纯图标按钮 = 圆形。**
 *
 * 全应用只有这一种圆形按钮实现。此前的毛病是圆形 / 胶囊 / 圆角矩形混用，
 * 界面上同一行里三种形状并存，很乱。
 */
@Composable
fun IconCircleButton(
    icon: ImageVector,
    contentDescription: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 36.dp,
    iconSize: Dp = 18.dp,
    enabled: Boolean = true,
    /** 非空则铺一层底色。 */
    background: Color? = null,
    tint: Color? = null,
    /** 描边。与「图标 + 箭头」的胶囊入口保持同一套视觉语言。 */
    outlined: Boolean = false,
    outlineColor: Color? = null,
    /** 形状。默认圆形；配合更宽的 [width] 传 `PillShape` 就是胶囊。 */
    shape: Shape = CircleShape,
    /** 宽。默认与 [size] 相同（正方形/圆）；胶囊形要显式给一个更宽的值。 */
    width: Dp = size,
    animateIcon: Boolean = false,
) {
    val colors = LocalChatColors.current
    val resolvedTint = tint ?: when {
        !enabled -> colors.placeholder
        else -> MaterialTheme.colorScheme.onSurface
    }
    Box(
        modifier = modifier
            .width(width)
            .height(size)
            .clip(shape)
            .then(if (background != null) Modifier.background(background) else Modifier)
            .then(
                if (outlined) {
                    Modifier.border(
                        width = 1.dp,
                        color = outlineColor ?: colors.outline,
                        shape = shape,
                    )
                } else {
                    Modifier
                },
            )
            .pressableClickable(enabled = enabled, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (animateIcon) {
            Crossfade(
                targetState = icon,
                modifier = Modifier.size(iconSize).semantics {
                    if (contentDescription != null) this.contentDescription = contentDescription
                },
                animationSpec = tween(160),
                label = "icon",
            ) { current -> Icon(current, null, tint = resolvedTint, modifier = Modifier.size(iconSize)) }
        } else {
            Icon(icon, contentDescription, tint = resolvedTint, modifier = Modifier.size(iconSize))
        }
    }
}

@Composable
internal fun CopyIconButton(size: Dp, iconSize: Dp, tint: Color, description: String, onCopy: () -> Unit) {
    var feedback by remember { mutableIntStateOf(0) }
    LaunchedEffect(feedback) {
        if (feedback != 0) {
            delay(1500)
            feedback = 0
        }
    }
    val copied = feedback != 0
    IconCircleButton(
        icon = if (copied) AppIcons.Check else AppIcons.Copy,
        contentDescription = if (copied) stringResource(R.string.md_copied) else description,
        onClick = {
            onCopy()
            feedback++
        },
        size = size,
        iconSize = iconSize,
        tint = if (copied) MaterialTheme.colorScheme.primary else tint,
        animateIcon = true,
    )
}

/**
 * **带文字的按钮 = 胶囊。**
 *
 * 用于「深度思考」「创作模式」这类标签，以及各处确认按钮。
 */
@Composable
fun CapsuleButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leadingIcon: ImageVector? = null,
    trailingIcon: ImageVector? = null,
    selected: Boolean = false,
    enabled: Boolean = true,
    /** true = 描边（默认）；false = 无边框的裸胶囊。 */
    outlined: Boolean = true,
) {
    val colors = LocalChatColors.current
    val contentColor = when {
        !enabled -> colors.placeholder
        selected -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.onSurface
    }

    val borderColor = if (selected) MaterialTheme.colorScheme.primary else colors.outline

    Row(
        modifier = modifier
            .clip(PillShape)
            .background(if (selected) colors.capsuleSelected else Color.Transparent)
            .then(
                if (outlined) {
                    Modifier.border(
                        width = 1.dp,
                        color = if (enabled) borderColor else colors.divider,
                        shape = PillShape,
                    )
                } else {
                    Modifier
                },
            )
            .pressableClickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        if (leadingIcon != null) {
            Icon(
                imageVector = leadingIcon,
                contentDescription = null,
                tint = contentColor,
                modifier = Modifier.size(16.dp),
            )
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium,
            color = contentColor,
            maxLines = 1,
        )
        if (trailingIcon != null) {
            Icon(
                imageVector = trailingIcon,
                contentDescription = null,
                tint = contentColor,
                modifier = Modifier.size(14.dp),
            )
        }
    }
}

// ══════════════════════════════════════════════════════════
//  长按菜单
// ══════════════════════════════════════════════════════════

/** 菜单宽度。**固定值** —— 宽度随内容浮动会让同一组件在每处长不一样。 */
val MenuWidth = 208.dp

/** 菜单项固定行高。46dp：离 48dp 的触控下限只差一点，视觉上又不至于太松散。 */
private val MenuItemHeight = Space.Row

/** 菜单与锚点的间隙。 */
private val MenuGap = 8.dp

/**
 * 为阴影预留的绘制空间。
 *
 * `Popup` 的窗口尺寸就是内容尺寸，阴影画在内容之外的部分会被直接裁掉 ——
 * 表现是浮层边缘"阴影断了"。预留一圈后阴影才能自然扩散。
 */
private val MenuShadowBleed = 30.dp

/**
 * 投影规格。**两档，全应用统一**。
 *
 * 关键：`elevation` 只决定**扩散范围**，浓淡由 `ambient/spot` 的 alpha
 * 单独控制 —— 两者拆开才谈得上"范围大但很淡"。
 *
 * 之前就栽在这里：输入栏用框架默认色（偏黑），菜单却用了 4% 的极淡色，
 * 于是「输入栏太浓、菜单看不见」，方向完全反了。
 */
object AppShadow {
    /**
     * 贴底大面板（输入栏、输入面板）。
     *
     * 面积大，同样的 alpha 会比小卡片显眼得多，所以两档之间保持一倍以上差距。
     * 数值是实机来回比对出来的：再低就"没有"，再高就"发脏"。
     */
    val PanelElevation = 8.dp
    val PanelAmbient = Color.Black.copy(alpha = 0.08f)
    val PanelSpot = Color.Black.copy(alpha = 0.14f)

    /** 浮层（菜单）与抽屉：需要明确"浮起来"。 */
    val RaisedElevation = 16.dp
    val RaisedAmbient = Color.Black.copy(alpha = 0.18f)
    val RaisedSpot = Color.Black.copy(alpha = 0.26f)

    /**
     * 贴边那一层的厚度。
     *
     * 单层大投影的问题是**边界发虚**：卡片像悬在半空、边缘糊掉，
     * 深色背景上尤其明显。再叠一层很薄的窄投影，边缘立刻"落地"，
     * 而远处那片淡阴影照旧化开 —— 这才是卡片浮起来的样子。
     */
    val ContactElevation = 3.dp
    val ContactColor = Color.Black.copy(alpha = 0.10f)

    /** 输入栏的贴边层更薄：它比菜单大得多，同一厚度会显脏。 */
    val PanelContactElevation = 2.dp
    val PanelContactColor = Color.Black.copy(alpha = 0.07f)
}

/**
 * **双层**投影：远处化开 + 贴边收拢。
 *
 * 为什么要两层：`Modifier.shadow` 一次只能给一种扩散。只给大范围 → 边缘发虚
 * （卡片像飘着）；只给贴边 → 没有"浮起来"的距离感。两层叠起来，
 * 宽的那层负责氛围、窄的那层负责边界。
 *
 * 顺序要紧：**先宽后窄**、且都在 `background` 之前 —— 阴影永远垫在卡片底下。
 * `clip = false` 也是必须的，否则投影会被自家圆角裁掉一圈。
 */
fun Modifier.layeredShadow(
    shape: androidx.compose.ui.graphics.Shape,
    elevation: Dp,
    ambient: Color,
    spot: Color,
    contactElevation: Dp,
    contactColor: Color,
): Modifier = this
    .shadow(
        elevation = elevation,
        shape = shape,
        clip = false,
        ambientColor = ambient,
        spotColor = spot,
    )
    .shadow(
        elevation = contactElevation,
        shape = shape,
        clip = false,
        ambientColor = contactColor,
        spotColor = contactColor,
    )

/**
 * 菜单定位。两条规则，按触发方式区分：
 *
 * - **点击控件触发**（外观、模型列表…）：贴在锚点下方，且**右边缘对齐锚点右边缘**。
 *   左对齐会让菜单从控件左侧"长出来"，和控件右对齐的布局（数值 + 箭头）对不上。
 * - **长按触发**：**跟手** —— 从手指落点弹出，而不是从控件左边缘。
 *
 * 横向越界钳回窗口内，下方放不下则翻到上方。
 */
private class AppMenuPositionProvider(
    private val gapPx: Int,
    /** 浮层内为阴影预留的空白（上下左右各一份，px）。 */
    private val bleedPx: Int,
    /** 长按落点（相对锚点，px）。非空即"跟手"模式。 */
    private val touchPoint: IntOffset?,
    /** 右对齐锚点右边缘。 */
    private val alignEnd: Boolean,
    /** 回报菜单最终落在落点的**哪一侧**（true = 被翻到了上方），用于选缩放支点。 */
    private val onSide: (above: Boolean) -> Unit = {},
) : PopupPositionProvider {

    override fun calculatePosition(
        anchorBounds: IntRect,
        windowSize: IntSize,
        layoutDirection: LayoutDirection,
        popupContentSize: IntSize,
    ): IntOffset {
        // popupContentSize 含 bleed，先还原出**卡片本身**的尺寸
        val cardWidth = popupContentSize.width - bleedPx * 2
        val cardHeight = popupContentSize.height - bleedPx * 2

        // 让卡片连同阴影一起留在窗口内
        val minX = bleedPx
        val maxX = (windowSize.width - cardWidth - bleedPx).coerceAtLeast(minX)
        val minY = bleedPx
        val maxY = (windowSize.height - cardHeight - bleedPx).coerceAtLeast(minY)

        // ── 横向 ───────────────────────────────────────────
        /*
         * 长按跟手时**以落点为水平中心**。
         *
         * 早先是"左边缘对齐落点"，于是菜单整个挂在手指右边，
         * 而缩放的支点又取自身中线 —— 两个"中心"差着半个菜单宽，
         * 看起来就像"从菜单左边长出来"。居中之后，菜单中线 = 落点 = 支点。
         */
        val desiredX = when {
            touchPoint != null -> anchorBounds.left + touchPoint.x - cardWidth / 2
            alignEnd -> anchorBounds.right - cardWidth
            else -> anchorBounds.left
        }
        val cardX = desiredX.coerceIn(minX, maxX)

        // ── 纵向：优先在下方 ────────────────────────────────
        val belowY = when {
            touchPoint != null -> anchorBounds.top + touchPoint.y + gapPx
            else -> anchorBounds.bottom + gapPx
        }
        val cardY = if (belowY + cardHeight <= maxY + bleedPx) {
            belowY
        } else {
            // 翻到上方：长按模式下以落点为准，否则以锚点顶部为准
            val aboveY = when {
                touchPoint != null -> anchorBounds.top + touchPoint.y - cardHeight - gapPx
                else -> anchorBounds.top - cardHeight - gapPx
            }
            aboveY
        }
        // 告诉上层"最后落在落点的哪一侧"（长按跟手时缩放支点要靠它）
        if (touchPoint != null) onSide(cardY != belowY)
        val clampedY = cardY.coerceIn(minY, maxY)

        return IntOffset(cardX - bleedPx, clampedY - bleedPx)
    }
}

/**
 * 触摸本区域时收起输入法与焦点，**不消费事件**。
 *
 * 用 `PointerEventPass.Initial` 读一眼就走：被点的控件（消息气泡、按钮）
 * 照常收到事件。若改用 `clickable`，会把落在这一层上的点击**吃掉**，
 * 气泡就点不动了。
 *
 * 挂在消息区、顶栏这类"非输入"区域上；**不要**挂在输入栏自身，
 * 否则点输入框反而会把键盘收掉。
 */
@Composable
fun Modifier.dismissKeyboardOnTouch(clearFocus: () -> Boolean = { true }): Modifier {
    val focusManager = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val shouldClearFocus by rememberUpdatedState(clearFocus)

    return this.pointerInput(Unit) {
        awaitPointerEventScope {
            while (true) {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                val change = event.changes.firstOrNull() ?: continue
                if (change.pressed && !change.previousPressed) {
                    // A text selection also owns focus. Clearing it on DOWN destroys the
                    // range before we can distinguish a tap from a scroll.
                    if (shouldClearFocus()) focusManager.clearFocus()
                    keyboard?.hide()
                }
            }
        }
    }
}

/**
 * 记录最近一次按下的落点（相对当前节点，px），**不消费事件**。
 *
 * `combinedClickable` 的 `onLongClick` 不提供坐标，所以只能自己旁听一次
 * 按下事件 —— 用 `PointerEventPass.Initial` 在 Main 之前读一眼就走，
 * 不 `consume()`，点击、水波纹、长按都照常工作。
 *
 * @return `first` 取当前落点，`second` 是必须挂到目标节点上的 Modifier
 */
@Composable
fun rememberPressPosition(): Pair<() -> IntOffset, Modifier> {
    val position = remember { mutableStateOf(IntOffset.Zero) }

    val listener = Modifier.pointerInput(Unit) {
        awaitPointerEventScope {
            while (true) {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                val change = event.changes.firstOrNull() ?: continue
                if (change.pressed && !change.previousPressed) {
                    position.value = IntOffset(
                        x = change.position.x.roundToInt(),
                        y = change.position.y.roundToInt(),
                    )
                }
            }
        }
    }

    return ({ position.value }) to listener
}

/**
 * 记录最近一次按下的**窗口坐标**（px），**不消费事件**。
 *
 * 与 [rememberPressPosition] 的分工：
 * - 那个给的是"相对当前节点"的坐标 —— 菜单要跟手弹出，用的是锚点坐标系；
 * - 这里给的是**绝对位置**：「选择文本」要在这同一个点上合成一次长按，
 *   而注入触摸事件用的是窗口坐标系。
 *
 * 用 `PointerEventPass.Initial` 在 Main 之前读一眼就走，不 `consume()`，
 * 因此点击、水波纹、长按、选区都照常工作。
 *
 * @return `first` 取当前落点（还没按过时为 null），`second` 是必须挂到目标节点上的 Modifier
 */
@Composable
fun rememberPressWindowPosition(): Pair<() -> IntOffset?, Modifier> {
    val coordinates = remember { mutableStateOf<LayoutCoordinates?>(null) }
    val position = remember { mutableStateOf<IntOffset?>(null) }

    val listener = Modifier
        .onGloballyPositioned { coordinates.value = it }
        .pointerInput(Unit) {
            awaitPointerEventScope {
                while (true) {
                    val event = awaitPointerEvent(PointerEventPass.Initial)
                    val change = event.changes.firstOrNull() ?: continue
                    if (change.pressed && !change.previousPressed) {
                        val node = coordinates.value
                        position.value = if (node != null && node.isAttached) {
                            val inWindow = node.localToWindow(change.position)
                            IntOffset(inWindow.x.roundToInt(), inWindow.y.roundToInt())
                        } else {
                            null
                        }
                    }
                }
            }
        }

    return ({ position.value }) to listener
}

/** 菜单弹出 / 收起的时长。快 —— 菜单是"点一下就该出现"的东西，不能有等待感。 */
private const val MenuAnimMs = 140

/**
 * 圆角卡片菜单 —— **全应用唯一的菜单实现**。
 *
 * 刻意不用 Material3 的 `DropdownMenu`：
 * - 它内部会注入 `MenuDefaults.VerticalPadding`（8dp），我们改不掉，
 *   于是菜单顶部/底部总有一道多余的空白；
 * - 行高固定 48dp、宽度随内容浮动，抽屉和对话页两处就会长得不一样。
 *
 * 自绘 `Popup` 后这三件事都由我们说了算，抽屉与对话页的菜单因此能完全同形。
 *
 * `focusable = true` 换来了「点外部关闭」与「返回键关闭」——
 * 这两件事必须自己接回来，否则菜单会关不掉。
 *
 * ### 为什么需要一个 `mounted`
 *
 * `Popup` 是**独立窗口**，原先的 `if (!expanded) return` 会让它在一帧内消失，
 * 根本没有做退出动画的余地。这里多留一拍：`expanded` 变 false 后先把退出动画
 * 播完，再把 Popup 摘掉。
 */
@Composable
fun AppMenu(
    expanded: Boolean,
    onDismissRequest: () -> Unit,
    modifier: Modifier = Modifier,
    width: Dp = MenuWidth,
    /** 长按触发时传落点（px，相对锚点）→ 菜单跟手弹出。 */
    touchPoint: IntOffset? = null,
    /** 点击控件触发时默认右对齐锚点右边缘。 */
    alignEnd: Boolean = true,
    content: @Composable ColumnScope.() -> Unit,
) {
    val colors = LocalChatColors.current
    val density = LocalDensity.current
    val gapPx = with(density) { MenuGap.roundToPx() }
    val bleedPx = with(density) { MenuShadowBleed.roundToPx() }

    /*
     * 支点的 y 要跟着"菜单落在落点上方还是下方"走 —— 位置提供者才知道，
     * 所以用一个普通容器接它回报的值。
     *
     * 刻意**不用** Compose 状态：`graphicsLayer` 的 lambda 每帧都会重跑
     * （`progress.value` 在变），届时自然会读到最新值；而写成状态会在
     * layout 期间触发重组，得不偿失。
     */
    val aboveAnchor = remember { booleanArrayOf(false) }

    val positionProvider = remember(gapPx, bleedPx, touchPoint, alignEnd, aboveAnchor) {
        AppMenuPositionProvider(gapPx, bleedPx, touchPoint, alignEnd) { above ->
            aboveAnchor[0] = above
        }
    }

    var mounted by remember { mutableStateOf(expanded) }
    val progress = remember { Animatable(0f) }

    LaunchedEffect(expanded) {
        if (expanded) {
            mounted = true
            /*
             * ⚠️ 等两帧再起动画。`Popup` 是**新建一个窗口**，从 `mounted = true`
             * 到它真正上屏要一两帧；不等的话 140ms 的动画已经跑掉一截，
             * 看起来就"没有从手指处放大"这一步，只剩淡入。
             */
            withFrameNanos { }
            withFrameNanos { }
            progress.animateTo(1f, tween(MenuAnimMs, easing = MotionEasing))
        } else {
            progress.animateTo(0f, tween(MenuAnimMs, easing = MotionEasing))
            mounted = false
        }
    }

    if (!mounted) return

    Popup(
        popupPositionProvider = positionProvider,
        onDismissRequest = onDismissRequest,
        properties = PopupProperties(focusable = true),
    ) {
        Column(
            modifier = modifier
                // 先留出阴影的绘制空间：Popup 的窗口会裁掉超出内容的部分，
                // 不预留的话阴影就在边缘被切掉一道
                .padding(MenuShadowBleed)
                .width(width)
                .graphicsLayer {
                    // 只到 1f 为止 —— Popup 的窗口就是内容尺寸，放大只会被裁掉。
                    // 从更小的 0.6 起手：让"从手指处长大"看得见，而不是像纯淡入。
                    val s = 0.6f + 0.4f * progress.value
                    scaleX = s
                    scaleY = s
                    alpha = progress.value
                    /*
                     * 支点 = **贴着手指的那个角**。
                     *
                     * 纵向：看菜单位于落点的**哪一侧** —— 在下方取 0（顶），
                     * 被翻到上方取 **1（底）**，只有底边才贴着手指。
                     *
                     * 横向：**取中点**，不跟手指。
                     * 跟手时菜单左边缘虽起于落点，但它挺宽，长按又多在右半屏
                     * （消息气泡右对齐），`desiredX` 会被 `coerceIn` 钳回窗口内 ——
                     * 左边缘离手指可能差几百像素，拿它当支点必然"左右不对"。
                     * 菜单宽度固定、位置被钳过，横向支点本来就没有可靠信息，
                     * 索性从中间缩放。（点击触发的菜单贴着锚点右缘，仍取右上。）
                     */
                    transformOrigin = TransformOrigin(
                        if (touchPoint != null) 0.5f else 1f,
                        if (touchPoint != null && aboveAnchor[0]) 1f else 0f,
                    )
                }
                .layeredShadow(
                    shape = MenuShape,
                    elevation = AppShadow.RaisedElevation,
                    ambient = AppShadow.RaisedAmbient,
                    spot = AppShadow.RaisedSpot,
                    contactElevation = AppShadow.ContactElevation,
                    contactColor = AppShadow.ContactColor,
                )
                .clip(MenuShape)
                .background(colors.menuBackground)
                .border(1.dp, colors.outline, MenuShape)
                // 总上下内边距只有 4dp，之前是 6 + Material 的 8
                .padding(vertical = 4.dp),
            content = content,
        )
    }
}

/** 菜单项：图标 + 文字，固定 [MenuItemHeight] 行高。 */
@Composable
fun AppMenuItem(
    label: String,
    icon: ImageVector? = null,
    destructive: Boolean = false,
    /** 单选菜单里的选中态：右侧显示品牌色勾。 */
    selected: Boolean = false,
    onClick: () -> Unit,
) {
    val colors = LocalChatColors.current
    val contentColor = if (destructive) colors.danger else MaterialTheme.colorScheme.onSurface

    // 左右各留 4dp，水波纹才是圆角块而不是顶到卡片圆角上
    Box(modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(MenuItemHeight)
                .clip(SoftShape)
                .clickable(onClick = onClick)
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(18.dp),
                )
            }
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = contentColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                // fill = true：文字吃掉剩余空间，勾才会被顶到最右边
                modifier = Modifier.weight(1f),
            )
            AppMenuCheck(selected = selected)
        }
    }
}

/**
 * 菜单分组分隔线。
 *
 * 用法固定：**接在危险操作之前**。这样「有没有版本」「有几个版本」
 * 这类数据差异不会改变菜单的结构。
 */
@Composable
fun AppMenuDivider() {
    val colors = LocalChatColors.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .height(1.dp)
            .background(colors.divider),
    )
}

/** 菜单里的选中勾（用于外观 / 模型等单选菜单）。 */
@Composable
fun AppMenuCheck(selected: Boolean) {
    Box(modifier = Modifier.size(19.dp), contentAlignment = Alignment.Center) {
        Icon(
            imageVector = AppIcons.Check,
            contentDescription = null,
            tint = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
            modifier = Modifier.size(17.dp),
        )
    }
}


