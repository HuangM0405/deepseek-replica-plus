package com.simplechat.app.ui.common

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import com.simplechat.app.ui.theme.LocalChatColors

/**
 * 本地用户头像。
 *
 * 有图片就画图片，没有就画一个人像占位。读的是 [com.simplechat.app.data.LocalAvatar]
 * 落盘后的 256px 小图（几十 KB），直接在组合里解码，不需要额外的图片库。
 */
@Composable
fun ProfileAvatar(path: String, size: Dp, modifier: Modifier = Modifier) {
    val colors = LocalChatColors.current
    val bitmap = remember(path) {
        path.takeIf { it.isNotBlank() }
            ?.let { runCatching { BitmapFactory.decodeFile(it) }.getOrNull() }
            ?.asImageBitmap()
    }
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        } else {
            Icon(
                imageVector = AppIcons.User,
                contentDescription = null,
                tint = colors.placeholder,
                modifier = Modifier.fillMaxSize(0.55f),
            )
        }
    }
}
