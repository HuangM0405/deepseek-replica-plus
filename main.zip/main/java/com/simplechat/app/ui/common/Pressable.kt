package com.simplechat.app.ui.common

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.semantics.Role

/**
 * 带按压缩放的 clickable。
 *
 * 手机上按钮「按不动」是最常见的廉价感来源：点下去没有任何反馈，用户会怀疑
 * 是不是没点上，于是再点一次。官方客户端用的是 0.97 的缩放（Replica
 * Button.module.css 的 &:active），这里把它变成全应用唯一的手感来源。
 *
 * **只给按钮用，不给列表行用。** 列表行滑动时跟着缩放会抖，微信 / DeepSeek
 * 也都不这么做。
 *
 * 缩放在 graphicsLayer 的 scale 里做，只走绘制、不触发布局；水波纹
 * （LocalIndication）与缩放共用同一个 MutableInteractionSource，按下时
 * 两者同时开始。
 *
 * @param enabled 为 false 时不缩放，也不响应点击。
 * @param role 读屏语义；纯图标按钮传 Role.Button。
 * @param onClickLabel 读屏点击提示（例如「复制」）。
 */
@Composable
fun Modifier.pressableClickable(
    enabled: Boolean = true,
    role: Role? = null,
    onClickLabel: String? = null,
    onClick: () -> Unit,
): Modifier {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (pressed && enabled) PressedScale else 1f,
        animationSpec = tween(
            durationMillis = if (pressed) PressDownMs else PressReleaseMs,
            easing = PressEasing,
        ),
        label = "pressScale",
    )

    return this
        .scale(scale)
        .clickable(
            interactionSource = interaction,
            indication = LocalIndication.current,
            enabled = enabled,
            role = role,
            onClickLabel = onClickLabel,
            onClick = onClick,
        )
}
