package com.simplechat.app.ui.common

/**
 * 弹层动效的纯换算。
 *
 * 单独放一个文件、不引 Compose —— 这样位移/缩放/时长这几条曲线能直接跑 JVM 单测，
 * 不用起模拟器就能证明「progress=0 时卡片确实在屏幕外、progress=1 时确实归位」。
 */

/**
 * 底部卡片的下移量：progress=0 时整张卡在屏幕下方（下移一个自身高度），
 * progress=1 时归位。
 *
 * 用**自身高度**当行程，而不是写死的 300dp：
 * 来源面板和引用卡的个子差得远，写死会让矮的那张「滑一半就停」。
 */
internal fun sheetOffsetPx(progress: Float, heightPx: Float): Float =
    heightPx * (1f - progress.coerceIn(0f, 1f))

/** 居中弹窗的缩放：0.96 → 1。 */
internal fun modalScale(progress: Float): Float {
    val p = progress.coerceIn(0f, 1f)
    return ModalEnterScale + (1f - ModalEnterScale) * p
}

/** 遮罩不透明度：0 → maxAlpha。 */
internal fun scrimAlpha(progress: Float, maxAlpha: Float = 1f): Float =
    progress.coerceIn(0f, 1f) * maxAlpha

/**
 * 减弱动态下的时长：直接 0（跳变到终态）。
 *
 * 不返回一个很小的数 —— 5ms 的动画仍然是动画，看着只是一次掉帧。
 */
internal fun resolvedMs(baseMs: Int, reduceMotion: Boolean): Int = if (reduceMotion) 0 else baseMs
