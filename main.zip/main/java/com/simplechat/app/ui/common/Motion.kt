package com.simplechat.app.ui.common

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.ui.unit.IntOffset

/**
 * 全局转场规格。
 *
 * **所有页面切换都从这里取** —— 时长、缓动、位移量只定义一次。
 * 不然「设置页滑 1/4 屏、搜索页滑 1/3 屏」这种不一致会一处长出来，
 * 而转场恰恰是那种每一处都差一点、整体就是不对劲的东西。
 */

/**
 * 转场时长 300ms。
 *
 * 对齐 Android 平台自己的 Activity 切换（Material 的 medium 档）。
 * 再短会"闪一下"，再长有拖沓感 —— 平台选这个数是有原因的。
 *
 * 抽屉展开成搜索页也用它，两处节奏才是一致的。
 */
const val MotionDurationMs = 300

/**
 * 折叠 / 展开的时长 220ms。
 *
 * 比转场快一档 —— 折叠的距离往往很大（一条几万像素的消息），拖久了会像在等它。
 * **用户气泡与思考面板共用这一个数**：两处都是"折叠"，节奏不一致会很明显。
 */
const val FoldAnimMs = 220

/** 缓动：平台标准的先快后慢。 */
val MotionEasing: Easing = FastOutSlowInEasing

/**
 * 按压反馈的缩放目标。
 *
 * 0.97 —— 只看得出「按进去了」，看不出「缩了一下」。再小就是弹跳玩具。
 * 与官方客户端的 0.97 一致（Replica Button.module.css:24）。
 */
const val PressedScale = 0.97f

/**
 * 按下 90ms、回弹 160ms —— 不对称是刻意的。
 *
 * 按下去要立刻跟手（慢了像没反应），回来要稍缓（快了像抽筋）。
 * 两段用同一个时长反而两头都不对。
 */
const val PressDownMs = 90
const val PressReleaseMs = 160

/** 按压反馈缓动：与页面转场同一档，摸起来是同一个应用。 */
val PressEasing: Easing = FastOutSlowInEasing

/**
 * 弹层缓动：cubic-bezier(0.23, 1, 0.32, 1)。
 *
 * 平台自带的 FastOutSlowIn 起步没那么快，压在 200ms 上下的弹层里会显得「推一下才动」。
 * 这条曲线一开始就吃掉大半行程、落点收得很平，是浮层该有的手感。
 */
val PopupEasing: Easing = CubicBezierEasing(0.23f, 1f, 0.32f, 1f)

/**
 * 让位缓动：起步慢、后段快。
 *
 * 收起输入栏面板时，键盘几乎同时在往下走（点输入框则是往上走）。两条高度动画
 * 各播各的，只要面板起步稍快一点，合成出来的高度就会先掉再涨 —— 用户看到的就是
 * 「下坠一下又弹回来」。这条曲线让面板前 40% 行程几乎不动，把空间先让给键盘，
 * 之后一口气收掉；而 [PopupEasing] 正好相反，展开时先吃掉大半行程，赶在键盘
 * 退场前把高度补上。
 */
val PanelYieldEasing: Easing = CubicBezierEasing(0.55f, 0f, 1f, 0.45f)

/**
 * 弹层时长。**退出统一比进入短**：用户已经决定离开了，不该再等它播完。
 *
 * - [SheetEnterMs] / [SheetExitMs]：底部卡片（引用预览卡、来源面板）—— 行程长，给足 260。
 * - [DialogEnterMs] / [DialogExitMs]：居中小弹窗 —— 位移几乎为零，200 就够。
 * - [InlineEnterMs] / [InlineExitMs]：行内出现的一小条（来源条、错误行、加载圈）。
 */
const val SheetEnterMs = 260
const val SheetExitMs = 180
const val DialogEnterMs = 200
const val DialogExitMs = 150
const val InlineEnterMs = 180
const val InlineExitMs = 140

/**
 * 居中小弹窗的起始缩放。
 *
 * 0.96 —— 弹层不能从 0 蹦出来，0.96 已经足够让眼睛读出「它是浮上来的」。
 */
const val ModalEnterScale = 0.96f

/**
 * 页面转场。
 *
 * ```
 * 前进 ── 新页从右侧整屏推入，旧页整屏推向左侧
 * 后退 ── 反过来
 * ```
 *
 * **两个刻意的选择**：
 *
 * 1. **整屏推，不是推一半**。出场页只推 1/3 屏的话，中途两页会在屏幕中间
 *    叠成重影；整屏推则两页首尾相接、严丝合缝，全程没有重叠也没有空档。
 * 2. **不叠淡入淡出**。位移途中两页都是半透明的，底下的空白会透出来，
 *    正是上面那团"糊"的来源。平台自己的 Activity 切换也不带淡出。
 *
 * 全屏页面之间的横向切换，本来就该是这个样子。
 *
 * @param forward 目标页比当前页**更深**（往栈里压）时为 true。
 *   同级之间互不跳转，所以只判深度就够。
 */
fun AnimatedContentTransitionScope<*>.screenTransform(forward: Boolean): ContentTransform {
    val slide = tween<IntOffset>(MotionDurationMs, easing = MotionEasing)

    val enter = slideInHorizontally(slide) { width -> if (forward) width else -width }
    val exit = slideOutHorizontally(slide) { width -> if (forward) -width else width }

    return enter togetherWith exit
}
