package com.simplechat.app.ui.common

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.util.concurrent.atomic.AtomicLong

/**
 * 全局轻提示。
 *
 * 不用系统 Toast：它固定出现在屏幕下方、样式完全由系统决定（各家 ROM 还
 * 不一样），和本应用的深色浮层放在一起就是「两个应用」。
 * Replica 用自绘的深色胶囊（Toast.module.css:29-36），这里沿用它的观感：
 * 屏幕居中、#202020 86% 不透明、16dp 圆角、白字 14sp。
 *
 * 调用方不需要 Compose 上下文：show / showError 可以从协程、回调、ViewModel
 * 里直接调用，宿主 AppToastHost 挂在 MainActivity 根部。
 */
object AppToast {
    private val ids = AtomicLong()

    /*
     * 没有订阅者时 SharedFlow 会直接丢弃事件 —— 宿主是常驻的（MainActivity
     * 根部），所以不留 replay。真在宿主挂载前弹出，丢掉的也只是启动瞬间的
     * 一条提示；留 replay=1 反而会让同一句提示在重建后重复出现。
     */
    private val _events = MutableSharedFlow<AppToastMessage>(
        extraBufferCapacity = 16,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )
    internal val events: SharedFlow<AppToastMessage> = _events.asSharedFlow()

    fun show(text: String) = emit(text, error = false)

    fun showError(text: String) = emit(text, error = true)

    private fun emit(text: String, error: Boolean) {
        val body = text.trim()
        if (body.isEmpty()) return
        _events.tryEmit(AppToastMessage(id = ids.incrementAndGet(), text = body, error = error))
    }
}

/** 一条提示。id 用来区分连续两条相同文案（不能靠 equals 去重）。 */
internal data class AppToastMessage(
    val id: Long,
    val text: String,
    val error: Boolean,
)

/** 最多排 3 条：再多只说明用户在连点，没必要把提示排成一分钟。 */
private const val MaxQueuedToasts = 3

private const val ToastEnterMs = 200
private const val ToastExitMs = 160

/** 深色胶囊：#202020、86% 不透明。深浅色模式都不换色。 */
private val ToastBackground = Color(0xDB202020)

/** 错误图标用的红：比主题 danger 亮一档，压在深色底上才看得清。 */
private val ToastErrorIcon = Color(0xFFFF6B6B)

/**
 * 轻提示宿主。**只挂一次**，放在 MainActivity 的根 Box 里。
 *
 * 事件进队列串行播放：连着弹两条时不会互相盖掉，也不会挤成一片。
 */
@Composable
fun AppToastHost(modifier: Modifier = Modifier) {
    val queue = remember { mutableStateListOf<AppToastMessage>() }

    LaunchedEffect(Unit) {
        AppToast.events.collect { message ->
            if (queue.size >= MaxQueuedToasts) queue.removeAt(0)
            queue.add(message)
        }
    }

    val current = queue.firstOrNull()

    /*
     * 退场时 current 已经是 null，但 AnimatedVisibility 还要把内容画到动画
     * 结束，所以文字必须留在 displayed 里 —— 直接读 current 会让提示在淡出的
     * 第一帧就变成空白。
     */
    var displayed by remember { mutableStateOf<AppToastMessage?>(null) }
    LaunchedEffect(current?.id) {
        if (current != null) displayed = current
    }

    LaunchedEffect(current?.id) {
        val message = current ?: return@LaunchedEffect
        delay(toastDurationMs(message))
        val index = queue.indexOfFirst { it.id == message.id }
        if (index >= 0) queue.removeAt(index)
    }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        AnimatedVisibility(
            visible = current != null,
            enter = fadeIn(tween(ToastEnterMs)) +
                slideInVertically(tween(ToastEnterMs)) { height -> -height / 4 },
            exit = fadeOut(tween(ToastExitMs)) +
                slideOutVertically(tween(ToastExitMs)) { height -> -height / 4 },
        ) {
            displayed?.let { ToastPill(it) }
        }
    }
}

@Composable
private fun ToastPill(message: AppToastMessage) {
    Row(
        modifier = Modifier
            .padding(horizontal = 28.dp)
            .widthIn(max = 480.dp)
            .background(ToastBackground, RoundedCornerShape(16.dp))
            .padding(horizontal = 18.dp, vertical = 12.dp)
            .semantics { liveRegion = LiveRegionMode.Polite },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (message.error) {
            Icon(
                imageVector = AppIcons.Alert,
                contentDescription = null,
                tint = ToastErrorIcon,
                modifier = Modifier.size(16.dp),
            )
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text = message.text,
            color = Color.White,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = if (message.error) TextAlign.Start else TextAlign.Center,
        )
    }
}

/**
 * 停留时长：1.6 秒起步，每字 +40ms，封顶 4 秒。
 *
 * 固定 2 秒对「已复制」够用，对一条报错却读不完；按字数给时间才合理。
 */
internal fun toastDurationMs(message: AppToastMessage): Long =
    (1600L + message.text.length * 40L).coerceAtMost(4000L)
